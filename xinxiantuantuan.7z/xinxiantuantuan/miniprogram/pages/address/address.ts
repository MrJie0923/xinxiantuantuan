Page({
  data: {
    addressList: [],

    showAddAddressModal: false
  },

  onSearchInput(e) {
    const query = e.detail.value;
    // 搜索逻辑
  },

  selectAddress(e) {
    // 返回订单弹框并传递参数
    const selectedAddress = this.data.addressList.find(item => item.id === e.currentTarget.dataset.id);

    // 将选中的地址存储在本地缓存中
    wx.setStorageSync('selectedAddress', selectedAddress);
  
    // 返回订单页面
    wx.navigateBack();
  },

  

  editAddress(e) {
    const id = e.currentTarget.dataset.id;
    // 编辑逻辑
  },

  deleteAddress(e) {
    const id = e.currentTarget.dataset.id;
    // 删除逻辑
  },

  showAddAddressPopup() {
    this.setData({ showAddAddressModal: true });

  },

  onNameInput(e) {
    this.setData({ 'newAddress.name': e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ 'newAddress.phone': e.detail.value });
  },

  onCommunityChange(e) {
    const index = e.detail.value;
    const selectedCommunity = this.data.communityList[index];
    this.setData({ selectedCommunity });
    // 根据选择的小区获取楼号和单元号
    this.fetchBuildingAndUnit(selectedCommunity);
  },

  onBuildingInput(e) {
    this.setData({ 'newAddress.building': e.detail.value });
  },

  onUnitInput(e) {
    this.setData({ 'newAddress.unit': e.detail.value });
  },

  onUnitChange(e) {
    const index = e.detail.value;
    const selectedUnit = this.data.unitList[index];
    this.setData({ selectedUnit });
  },

  onRoomInput(e) {
    this.setData({ 'newAddress.room': e.detail.value });
  },

  saveAddress() {
    // 保存地址逻辑
    const { name, phone, selectedCommunity, selectedBuilding, selectedUnit, room } = this.data;
    if (name && phone && selectedCommunity && selectedBuilding && selectedUnit && room) {
      // 保存地址到后台
      this.setData({ showAddAddressModal: false });
    } else {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
    }
  },

  fetchBuildingAndUnit(community) {
    // 根据社区获取楼号和单元号的逻辑
  }
});
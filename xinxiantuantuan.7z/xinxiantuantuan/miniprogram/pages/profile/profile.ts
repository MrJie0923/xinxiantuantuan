Page({
  data: {
    userInfo: null, // 用户信息
  },
  onLoad() {
    // 检查本地是否有用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({ userInfo });
    }
  },
  onUserInfoTap() {
    if (this.data.userInfo) {
      // 用户已登录，执行其他操作
      return;
    }
    // 用户未登录，跳转到登录页面
    wx.navigateTo({
      url: '/pages/login/login',
    });
  },
});
Page({
  data: {
    tabs: ['待配送', '已配送'],
    currentTab: 0,
    orders: []
  },

  onLoad() {
    this.fetchOrders();
  },

  switchTab(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({ currentTab: index });
    this.fetchOrders();
  },

  fetchOrders() {
    const { currentTab } = this.data;
    let orders = this.generateMockData();

    switch (currentTab) {
      case 0:
        this.setData({ orders: orders.filter(order => order.status === '待配送') });
        break;
      case 1:
        this.setData({ orders: orders.filter(order => order.status === '已配送') });
        break;
    }
  },

  generateMockData() {
    return [
      {
        id: '12345',
        status: '待配送',
        total: '¥100.00',
        date: '2024-12-01 10:30',
        deliveryMethod: '自提',
        items: [
          {
            name: '商品A',
            quantity: 2,
            price: '¥50.00',
            imageUrl: '/assets/images/Weixin Image_20241222003543.png'
          }
        ]
      },
      {
        id: '12346',
        status: '待配送',
        total: '200.00',
        date: '2024-11-30 15:45',
        deliveryMethod: '送货上门',
        items: [
          {
            name: '商品B',
            quantity: 1,
            price: '200.00',
            imageUrl: '/assets/images/Weixin Image_20241222003543.png'
          }
        ]
      },
      {
        id: '12347',
        status: '待配送',
        total: '¥150.00',
        date: '2024-11-29 09:20',
        deliveryMethod: '自提',
        items: [
          {
            name: '商品C',
            quantity: 3,
            price: '50.00',
            imageUrl: '/assets/images/Weixin Image_20241222003543.png'
          }
        ]
      },
      {
        id: '12348',
        status: '已配送',
        total: '¥300.00',
        date: '2024-12-02 08:10',
        deliveryMethod: '送货上门',
        items: [
          {
            name: '商品D',
            quantity: 6,
            price: '50.00',
            imageUrl: '/assets/images/Weixin Image_20241222003627.png'
          }
        ]
      }
    ];
  }
});
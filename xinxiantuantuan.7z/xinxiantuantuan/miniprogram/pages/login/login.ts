Page({
  data: {
    isAgreed: false, // 用户是否同意协议
  },
  onAgreementChange(e) {
    this.setData({
      isAgreed: e.detail.value.includes('agree'),
    });
  },
  onLogin() {
    if (!this.data.isAgreed) {
      wx.showToast({
        title: '请阅读并同意用户协议和隐私政策',
        icon: 'none',
      });
      return;
    }

    // 调用 wx.getUserProfile 获取用户信息
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
      success: (res) => {
        const userInfo = res.userInfo;

        // 保存到本地存储
        wx.setStorageSync('userInfo', userInfo);

        // 返回上一页并刷新数据
        const pages = getCurrentPages();
        if (pages.length > 1) {
          const prevPage = pages[pages.length - 2];
          prevPage.setData({ userInfo });
        }
        wx.navigateBack();
      },
      fail: () => {
        wx.showToast({
          title: '未授权，无法获取用户信息',
          icon: 'none',
        });
      },
    });
  },
});
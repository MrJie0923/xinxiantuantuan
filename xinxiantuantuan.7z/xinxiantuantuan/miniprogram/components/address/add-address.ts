Component({
  properties: {
    visible: {
      type: Boolean,
      value: false
    },
    communityList: Array,
    buildingList: Array,
    unitList: Array
  },
  data: {
    selectedCommunity: '',
    selectedBuilding: '',
    selectedUnit: '',
    name: '',
    phone: '',
    room: ''
  },
  // observers: {
  //   'visible': function(visible) {
  //     if (visible) {
  //       this.showModal();
  //     } else {
  //       this.hideModal();
  //     }
  //   }
  // },
  methods: {
    onNameInput(e) {
      this.setData({ name: e.detail.value });
    },
    onPhoneInput(e) {
      this.setData({ phone: e.detail.value });
    },
    onCommunityChange(e) {
      const index = e.detail.value;
      const selectedCommunity = this.data.communityList[index];
      this.setData({ selectedCommunity });
      // 根据选择的小区获取楼号和单元号
      this.fetchBuildingAndUnit(selectedCommunity);
    },
    onBuildingChange(e) {
      const index = e.detail.value;
      const selectedBuilding = this.data.buildingList[index];
      this.setData({ selectedBuilding });
    },
    onUnitChange(e) {
      const index = e.detail.value;
      const selectedUnit = this.data.unitList[index];
      this.setData({ selectedUnit });
    },
    onRoomInput(e) {
      this.setData({ room: e.detail.value });
    },
    saveAddress() {
      const { name, phone, selectedCommunity, selectedBuilding, selectedUnit, room } = this.data;
      if (name && phone && selectedCommunity && selectedBuilding && selectedUnit && room) {
        this.triggerEvent('save', { name, phone, selectedCommunity, selectedBuilding, selectedUnit, room });
      } else {
        wx.showToast({ title: '请填写完整信息', icon: 'none' });
      }
    },
    hideModal() {
      this.setData({ visible: false });
    }
  }
});